
package model;

/**
 *
 * @author elorza.karmele
 */
public interface Marrazgarria {
      public void marraztu();
}
